/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package login_poe_part1_;
import javax.swing.JOptionPane;
/**
 *
 * @author RC_Student_lab
 */
public class Login_poe_part1_ {

    /**
     * @param args the command line arguments
     */
   
        // Global variables 
    static String username;
    static String password;
    static String name;
    static String surname;

    public static void main(String[] args) {
        details();
        if (checkUser()) {
            if (checkPassword()) {
                login();
            }
        }
    }

    // Get details (name and surname)
    public static void details() {
        name = JOptionPane.showInputDialog("Enter your name");
        surname = JOptionPane.showInputDialog("Enter your surname");
    }

    // Check username
    public static boolean checkUser() {
        boolean validUser = false;
        while (!validUser) {
            username = JOptionPane.showInputDialog(null, "Enter username");

            // Username should contain an underscore and not exceed 5 characters
            if (username.contains("_") && username.length() <= 5) {
                JOptionPane.showMessageDialog(null, "Username successfully captured");
                validUser = true;
            } else {
                JOptionPane.showMessageDialog(null, "Username is not correctly formatted.\n"
                        + "- Please ensure that your username contains an underscore (_)\n"
                        + "- It should not be more than 5 characters.");
            }
        }
        return validUser;
    }

    // Check password
    public static boolean checkPassword() {
        boolean validPassword = false;
        while (!validPassword) {
            String inputPassword = JOptionPane.showInputDialog("Enter password");

            // Password conditions: at least 8 characters, one uppercase letter, one digit, and one special character
            if (inputPassword.length() >= 8 
                && inputPassword.matches(".*[A-Z].*")  // At least one uppercase letter
                && inputPassword.matches(".*\\d.*")    // At least one digit
                && inputPassword.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) { // At least one special character
                password = inputPassword;
                JOptionPane.showMessageDialog(null, "Password successfully captured");
                validPassword = true;
            } else {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted. Please enter the password again.\n"
                        + "- Minimum 8 characters\n"
                        + "- A capital letter\n"
                        + "- A number\n"
                        + "- A special character");
            }
        }
        return validPassword;
    }

    // Login method
    public static void login() {
        String user2 = JOptionPane.showInputDialog("You have successfully registered, please enter your username to login");
        String password2 = JOptionPane.showInputDialog("Please enter your password to login");

        if (user2.equals(username) && password2.equals(password)) {
            JOptionPane.showMessageDialog(null, "Welcome " + name + " " + surname + ", it's great to see you again.");
            System.exit(0);
        } else {
            JOptionPane.showMessageDialog(null, "You have entered the wrong username or password.\nPlease try again.");
            login();  // Call login again if the credentials don't match
        }
    }
}

    
    
